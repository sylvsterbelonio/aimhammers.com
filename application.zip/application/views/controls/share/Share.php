<script type="text/javascript" src="<?=base_url()?>js/jquery.min.1.8.2.js"></script>
<link rel="stylesheet" type="text/css" href="<?=base_url()?>controls/share/css/style.css" /> 
<ul  class="share-btn-wrp">
     <li class="facebook button-wrap">Facebook</li>
     <li class="twitter button-wrap">Tweet</li>
     <li class="gplus button-wrap">Google Share</li>
     <li class="email button-wrap">Email</li>
     <li class="digg button-wrap">Digg</li>
     <li class="stumbleupon button-wrap">StumbleUpon</li>
     <li class="delicious button-wrap">Delicious</li>                  
</ul> 
<script type="text/javascript" src="<?=base_url()?>controls/share/js/script.js"></script>           
