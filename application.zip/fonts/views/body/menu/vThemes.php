

<div id="switcher" style="float:right;font-size:10px;width:15%;padding:"></div>

<script>
$('#switcher').themeswitcher();
</script>
