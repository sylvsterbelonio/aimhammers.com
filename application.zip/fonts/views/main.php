<?php $this->load->view('header/header');?>
<body id="aim">
<?php $this->load->view('footer/footer');?>
