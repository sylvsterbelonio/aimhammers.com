<style>
.footer{
width:100%;
position:absolute;
bottom:0px;
background:#02520a;
border-top:3px solid #06ac16;
color:white;
}



</style>


