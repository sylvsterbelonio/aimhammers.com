<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      
		    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="" />
        <meta name="keywords" content="HAMMER, aimworld, aimglobal" />
		    <meta name="author" content="HAMMER - Project" />
        <link rel="shortcut icon" href="<?=base_url()?>images/icons/favicon.ico">
        		          <script type="text/javascript" src="<?=base_url()?>js/jquery.min.1.8.2.js"></script>
<title>Hammer - Aim Worldwide Blog</title>

<style>
body{
margin:0px;
font-family: "Arial Narrow", Arial Narrow, sans-serif;
font-size:150%;
min-width:400px;
}
.ui-content{
    background:#eeffab;
}

.header{
width:100%;
background:#137a1a;
height:40px;
border-top:1px solid #7ffb79;
border-bottom:3px solid #0f6f0a;
		background-image: -moz-linear-gradient(#23e11a, #0d8b07); 
		background-image: -webkit-gradient(linear, left top, left bottom, from(#23e11a), to(#0d8b07));	
		background-image: -webkit-linear-gradient(#23e11a, #0d8b07);	
		background-image: -o-linear-gradient(#23e11a, #0d8b07);
		background-image: -ms-linear-gradient(#23e11a, #0d8b07);
		background-image: linear-gradient(#23e11a, #0d8b07);
		-moz-box-shadow: 0 1px 1px #16a00f, 0 1px 0 #7ffb79 inset;
		-webkit-box-shadow: 0 1px 1px #16a00f, 0 1px 0 #7ffb79 inset;
		
}
</style>
</head>
<body class="ui-content">

