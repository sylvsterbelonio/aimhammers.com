<?php
$theme = $this->mdlGeneral->getTheme();


?>

<style>
.footer{
background:black;
max-width:<?=$theme["maxWidth"]?>px;
width:100%;
color:white;
text-align:center;
clear:both;
font-size:12px;
margin:0px auto;
padding:10px 10px 30px 10px;
font-family: 'Open Sans Condensed','Arial', serif;
}

.columnf{
float:left;
width:32%;
background:red;
}

.columnr{
float:right;
width:32%;
background:red;
}
.columnf-container{
clear:both;
background:black;
max-width:<?=$maxWidth?>px;
width:100%;
background:rbga(0,0,0,0.7)
display:block;
}

</style>


<div class="columnf-container">
asasd
  <div class="columnf">
  
  ZX
  </div>
  <div class="columnf">
  ZX
  
  </div>

  <div class="columnr">
  ZXZX
  
  </div>
</div>
<div class="footer">





This site is not the official website of Alliance in Motion Global, Inc. Powered by HAMMER.



</div>
