
<div class="ui-widget-content">
<span class="ui-state-error ui-corner-all align-center select-disabled">
<p>The Page you are trying to view is empty. Please check your settings or contact to the Administrator! Thank You!!
</p>
</span>
</div>
