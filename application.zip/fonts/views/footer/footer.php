    <div class="ui-widget-header">
    <p style="text-align:center;font-size:9px">Alliance in Motional Global Personal Blog Website. All Rights Reserved 2016 | This site is not the official website of Alliance in Motion Global, Inc.
    </p>
    </div>
</body>
</html>
