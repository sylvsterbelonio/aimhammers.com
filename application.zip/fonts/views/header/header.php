<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="images/icons/favicon.ico">
        <link type="text/css" href="<?=base_url()?>css/jquery-ui.css" rel="stylesheet" />
        <link type="text/css" href="<?=base_url()?>css/ui.jqgrid.css" rel="stylesheet" />  
        <script src="<?=base_url()?>js/ajaxupload.js" type="text/javascript" charset="utf-8"></script>   
        <script src="<?=base_url()?>js/jquery-1.7.2.min.js" type="text/javascript" charset="utf-8"></script>
        <script type="text/javascript" src="<?=base_url()?>js/grid.locale-en.js"  charset="utf-8"></script>
        <script src="<?=base_url()?>js/jquery.jqGrid.min.js" type="text/javascript" charset="utf-8"></script>
        <script src="<?=base_url()?>js/jquery.jqGrid.fluid.js" type="text/javascript" charset="utf-8"></script> 
        <script type="text/javascript" src="<?=base_url()?>js/jquery-ui.min.js"></script> 
        <script type="text/javascript" src="<?=base_url()?>js/themeswitcher.js"></script>  
        <script type="text/javascript" src="<?=base_url()?>js/clipboard.min.js"></script> 
        <script src="<?=base_url()?>js/jquery.json-2.2.js" type="text/javascript"></script>
        <script src="<?=base_url()?>js/jquery.json-2.2.min.js" type="text/javascript"></script>  
        <style>
        input,button,select,li,h3,textarea{
        border:none;
        outline:none; 
       }
        .ui-tabs-anchor{
         border:none;
        outline:none; 
        }
        
         body{
        padding:5px;

        }

body {
    background-image: url("<?=base_url()?>background.jpg");
    background-color: #cccccc;
}
        </style>
</head>
<title><?php echo $title;?></title>

<body id="core" >


