
$(function() {

    $( "#accordion" ).accordion({
      heightStyle: "fill",      collapsible: true
    });
    
    $( "#accordion" ).height($(window).height()-200).accordion( "refresh" );
  
  
  
  





});
  
  
